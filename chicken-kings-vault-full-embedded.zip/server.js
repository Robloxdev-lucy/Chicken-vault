
const express = require('express');
const path = require('path');
const app = express();

app.use(express.static('public'));
app.use(express.static('.'));

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));
app.get('/games.html', (req, res) => res.sendFile(path.join(__dirname, 'games.html')));

// Ultraviolet proxy route placeholder
app.get('/service/:url', (req, res) => {
  res.send(`<html><body><h1>Proxy Placeholder</h1><p>This would proxy: ${decodeURIComponent(req.params.url)}</p></body></html>`);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
